# OpenCode Reusable Skill Pack

This pack gives you a native OpenCode setup for reusable project workflows using:
- `.opencode/commands/` for repeatable task commands
- `.opencode/agents/` for specialized subagents
- `AGENTS.md` and `opencode.json` for always-on project rules

## What's included

### Commands
- `/scaffold-project <name> <type>`
- `/create-feature-spec <feature-name>`
- `/update-spec <summary>`
- `/create-api-spec <api-name>`
- `/create-adr <decision-title>`
- `/create-component <component-name>`
- `/review-requirement-impact <change-summary>`
- `/sync-spec-after-change <change-summary>`

### Agents
- `@docs-guardian`
- `@architect`
- `@api-designer`
- `@scaffold-engineer`
- `@ui-builder`

## Install

Copy the following into your project root:
- `.opencode/`
- `AGENTS.md`
- `opencode.json`
- `docs/spec-update-policy.md`
- `templates/specs/`

## Recommended workflow

1. Start with `/review-requirement-impact ...`
2. Create/update specs with `/create-feature-spec` or `/update-spec`
3. Implement code changes
4. Run `/sync-spec-after-change ...`
5. Ask `@docs-guardian` to verify spec completeness

## Notes

This pack is designed to be easy to adapt. Adjust model names in frontmatter and `opencode.json` to match the providers you actually use.
