# Recommended Project Structure

```text
project/
├── .opencode/
│   ├── agents/
│   └── commands/
├── docs/
│   ├── adr/
│   └── specs/
│       ├── api/
│       ├── product/
│       └── technical/
├── src/
├── tests/
├── AGENTS.md
└── opencode.json
```
