# Project Agent Rules

## Spec-first delivery
Whenever a request changes behavior, requirements, UX flow, workflow, API contract, data schema, permissions, validation rules, configuration semantics, or integration behavior, you must also update the corresponding specification document before marking the task complete.

## Definition of done
A requirement-related implementation is not complete unless:
1. the related spec is updated or created,
2. the impacted files are identified,
3. the final summary names the spec file changed,
4. any intentionally skipped spec update is explicitly justified.

## Default doc locations
- Product specs: `docs/specs/product/`
- Technical specs: `docs/specs/technical/`
- API specs: `docs/specs/api/`
- Decisions: `docs/adr/`

## Preferred workflow
1. Analyze impact first.
2. Update specs before or during implementation.
3. Keep code, spec, and ADR aligned.
4. Use concise sections and clear acceptance criteria.
