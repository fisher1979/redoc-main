# Spec Update Policy

Any requirement-related implementation must include a documentation update.

## Requirement-related changes include
- new feature
- behavior change
- workflow change
- API request/response/schema change
- permission/validation/rule changes
- UI flow/content structure changes
- integration or data contract changes
- configuration meaning changes

## Mandatory behavior
- Update the most relevant spec under `docs/specs/**`
- Create a new spec if none exists
- Update ADR if architecture or trade-offs changed
- Mention the updated files in the completion summary

## Completion rule
Do not mark a requirement-related task complete until the relevant spec is aligned with the implementation.
