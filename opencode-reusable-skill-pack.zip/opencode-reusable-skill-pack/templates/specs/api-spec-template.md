# API Spec: <api name>

## Purpose

## Endpoint
- Method:
- Path:

## Request
### Headers
### Path Params
### Query Params
### Body Schema

## Response
### Success Schema
### Error Cases

## Validation Rules

## Security / Auth

## Observability

## Backward Compatibility Notes
