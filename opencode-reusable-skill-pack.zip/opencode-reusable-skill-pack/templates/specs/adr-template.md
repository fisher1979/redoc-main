# ADR: <decision title>

## Status
Proposed

## Context

## Decision

## Options Considered

## Consequences

## Risks

## Follow-up Actions
