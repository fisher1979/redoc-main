# Feature Spec: <feature name>

## Background

## Problem Statement

## Goals

## Non-Goals

## User / Business Value

## Scope

## Functional Requirements

## UX / Content Flow

## Data / Validation Rules

## Dependencies

## Risks / Constraints

## Acceptance Criteria

## Open Questions
