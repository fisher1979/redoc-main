---
description: Create a new UI component with spec-aware structure
agent: build
---
Create a new UI component named `$ARGUMENTS`.

Requirements:
- Create the component in the appropriate source folder.
- Include props typing, basic accessibility considerations, and a minimal usage example.
- If this changes user-facing behavior, update or create a relevant spec in `docs/specs/product/`.
- Summarize the files created or changed.
