---
description: Create or update an API specification
agent: build
---
Create or update an API spec for `$ARGUMENTS`.

Requirements:
- Use `templates/specs/api-spec-template.md`.
- Save under `docs/specs/api/`.
- Include endpoint, request/response schema, validation, security, and backward compatibility notes.
- If implementation files already exist, align the spec to the code.
