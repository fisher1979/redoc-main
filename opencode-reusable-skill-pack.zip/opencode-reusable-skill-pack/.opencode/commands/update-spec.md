---
description: Update the most relevant spec after a requirement-related change
agent: build
---
Given this change summary: `$ARGUMENTS`

Tasks:
- Identify which existing spec(s) are affected.
- Update the relevant file under `docs/specs/**`.
- If no spec exists, create a new one in the appropriate folder.
- Keep the update concise but complete.
- Add a short note at the end listing what changed.
