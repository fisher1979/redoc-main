---
description: Reconcile implementation changes back into specs and ADRs
agent: build
---
Synchronize documentation after this implementation change: `$ARGUMENTS`

Tasks:
- Inspect recent changed files.
- Update the relevant feature spec, technical spec, and API spec if needed.
- Create or update an ADR if architecture changed.
- Add a concise changelog note in each updated document.
- Report exactly which documents were aligned.
