---
description: Create an architecture decision record
agent: build
---
Create an ADR for `$ARGUMENTS`.

Instructions:
- Use `templates/specs/adr-template.md`.
- Save the ADR under `docs/adr/` with a sortable filename.
- Clearly explain context, options considered, decision, consequences, and risks.
