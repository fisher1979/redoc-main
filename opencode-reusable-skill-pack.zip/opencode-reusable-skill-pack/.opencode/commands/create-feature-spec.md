---
description: Create a new feature spec from the standard template
agent: build
---
Create a feature specification for `$ARGUMENTS`.

Instructions:
- Use `templates/specs/feature-spec-template.md` as the base format.
- Save the result under `docs/specs/product/` with a slugged filename.
- Fill each section with concrete, implementation-ready detail.
- Include acceptance criteria and open questions.
- If a related spec already exists, update it instead of duplicating content.
