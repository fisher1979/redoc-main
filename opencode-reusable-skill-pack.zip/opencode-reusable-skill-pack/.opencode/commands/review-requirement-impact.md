---
description: Analyze what code, spec, API, and architecture areas a change impacts
agent: plan
---
Analyze the impact of this proposed change: `$ARGUMENTS`

Provide:
1. impacted code areas,
2. impacted spec files,
3. whether an ADR is needed,
4. implementation risks,
5. suggested sequence of work.

Do not make file changes unless explicitly asked.
