---
description: Create a standard project scaffold with docs, specs, rules, and starter folders
agent: build
---
Create a project scaffold named `$1` of type `$2`.

Requirements:
- Create the project folder if it does not exist.
- Add a practical structure for a production codebase.
- Include: `.opencode/`, `docs/specs/product/`, `docs/specs/technical/`, `docs/specs/api/`, `docs/adr/`, `src/`, `tests/`, `README.md`, `AGENTS.md`, and `opencode.json`.
- If the project type is `ui`, include a component-oriented structure.
- If the project type is `service`, include API/domain/service structure.
- If the project type is `agent`, include prompts, workflows, and tool integration folders.
- Use the templates in `templates/specs/` where useful.
- Add a short README describing the structure.
- Do not overwrite unrelated existing files without explaining why.
